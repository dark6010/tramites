<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
<div><h2>Site Search</h2><input type="text" value="<?php the_search_query(); ?>" name="s" id="s" />
</div>
</form>
