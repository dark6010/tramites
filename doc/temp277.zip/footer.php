
<div style="clear: both;">&nbsp;</div>
</div>
</div>
<!-- end page -->
</div>
<hr />
<div id="footer-wrapper">
  <div id="footer">
    <p> Design by <a href="http://www.freewpthemes.net/">Free WordPress Themes</a>&nbsp;&nbsp;&nbsp;&nbsp;Powered by <a href="http://wordpress.org/">WordPress</a> </p>
  </div>
</div>
<?php wp_footer(); ?>
<!--%@##--><div style="margin: 1em 0 3em 0; text-align: center;">Find more free <a href="http://www.freewebtemplates.com/wordpress-themes/">WordPress themes</a> at <a href="http://www.freewebtemplates.com/">Free Website Templates</a>.</div><!--##@%-->
</body></html>