<!-- start sidebars -->
<div id="sidebar1" class="sidebar">
	<ul>
	<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar1')): ?>
		<li>Please add some widgets here.</li>
	<?php endif; ?>
	</ul>
</div>

